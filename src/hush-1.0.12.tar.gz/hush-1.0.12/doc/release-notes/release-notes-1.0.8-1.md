Daira Hopwood (3):
      Don't rely on a finite upper bound on fee rate or priority.
      Simplify JoinSplit priority calculation. refs 1896
      Add check for JoinSplit priority as calculated by CCoinsViewCache::GetPriority.

Jack Grigg (1):
      Use a larger -rpcclienttimeout for slow performance measurements

Nathan Wilcox (2):
      Bump version numbers for v1.0.8-1.
      Commit the changes from gen-manpages.sh, except manually tweak the version strings.

str4d (2):
      Update tests to check actual infinity as well as INF_FEERATE
      Add unit test for security issue 2017-04-11.a

