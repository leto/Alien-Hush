# remove founder-reward test
